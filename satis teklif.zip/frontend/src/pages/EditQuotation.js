import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ArrowLeft, Plus, Trash2, Save, GitBranch, Lock, FileText } from "lucide-react";
import { toast } from "sonner";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const INCOTERMS = [
  "EXW", "FCA", "FOB", "CIF", "CPT", "DAP", "DDP",
  "Shipping cost is paid by customer",
  "Shipping cost is paid by Demart"
];

const EditQuotation = () => {
  const navigate = useNavigate();
  const { type, id } = useParams();
  const [customers, setCustomers] = useState([]);
  const [products, setProducts] = useState([]);
  const [representatives, setRepresentatives] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [revisions, setRevisions] = useState([]);
  const [statusDialogOpen, setStatusDialogOpen] = useState(false);
  
  const [formData, setFormData] = useState(null);
  const [statusForm, setStatusForm] = useState({
    offer_status: "",
    rejection_reason: "",
    invoice_number: ""
  });

  useEffect(() => {
    fetchQuotation();
    fetchCustomers();
    fetchProducts();
    fetchRepresentatives();
    fetchRevisions();
  }, [id]);

  const fetchQuotation = async () => {
    try {
      const response = await axios.get(`${API}/quotations/${id}`);
      setFormData(response.data);
      setStatusForm({
        offer_status: response.data.offer_status,
        rejection_reason: response.data.rejection_reason || "",
        invoice_number: response.data.invoice_number || ""
      });
    } catch (error) {
      console.error("Error fetching quotation:", error);
      toast.error("Failed to load quotation");
      navigate(`/quotations/${type}`);
    } finally {
      setLoading(false);
    }
  };

  const fetchCustomers = async () => {
    try {
      const response = await axios.get(`${API}/customers?is_active=true`);
      setCustomers(response.data);
    } catch (error) {
      console.error("Error fetching customers:", error);
    }
  };

  const fetchProducts = async () => {
    try {
      const response = await axios.get(`${API}/products?product_type=${type}&is_active=true`);
      setProducts(response.data);
    } catch (error) {
      console.error("Error fetching products:", error);
    }
  };

  const fetchRepresentatives = async () => {
    try {
      const response = await axios.get(`${API}/representatives?is_active=true`);
      setRepresentatives(response.data);
    } catch (error) {
      console.error("Error fetching representatives:", error);
    }
  };

  const fetchRevisions = async () => {
    try {
      const response = await axios.get(`${API}/quotations/${id}/revisions`);
      setRevisions(response.data);
    } catch (error) {
      console.error("Error fetching revisions:", error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type: inputType, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: inputType === 'checkbox' ? checked : value
    }));
  };

  const handleProductSelect = (index, productId) => {
    const product = products.find(p => p.id === productId);
    if (product) {
      const newItems = [...formData.line_items];
      newItems[index] = {
        ...newItems[index],
        product_id: productId,
        brand: product.brand || "",
        model: product.model || "",
        variant_id: "",
        variant_name: "",
        variant_sku: "",
        item_short_name: product.item_short_name,
        item_description: product.item_description || "",
        unit: product.default_unit,
        currency: product.default_currency,
        unit_price: product.default_unit_price,
        cost_price: product.cost_price || 0
      };
      setFormData(prev => ({ ...prev, line_items: newItems }));
    } else {
      const newItems = [...formData.line_items];
      newItems[index] = {
        ...newItems[index],
        product_id: "",
        brand: "",
        model: "",
        variant_id: "",
        variant_name: "",
        variant_sku: ""
      };
      setFormData(prev => ({ ...prev, line_items: newItems }));
    }
  };

  // Variant/Model seçimi
  const handleVariantSelect = (index, variantId) => {
    const item = formData.line_items[index];
    const product = products.find(p => p.id === item.product_id);
    
    if (product && product.models && product.models.length > 0) {
      const variant = product.models.find(m => m.id === variantId || m.model_name === variantId);
      if (variant) {
        const newItems = [...formData.line_items];
        newItems[index] = {
          ...newItems[index],
          variant_id: variant.id || variant.model_name,
          variant_name: variant.model_name,
          variant_sku: variant.sku || "",
          item_short_name: variant.model_name,
          item_description: variant.description || product.item_description || "",
          unit_price: variant.price || product.default_unit_price || 0
        };
        setFormData(prev => ({ ...prev, line_items: newItems }));
      }
    }
  };

  // Seçili ürünün modelleri var mı kontrol et
  const getProductModels = (productId) => {
    const product = products.find(p => p.id === productId);
    return product?.models || [];
  };

  const handleLineItemChange = (index, field, value) => {
    const newItems = [...formData.line_items];
    newItems[index][field] = value;
    setFormData(prev => ({ ...prev, line_items: newItems }));
  };

  const addLineItem = () => {
    setFormData(prev => ({
      ...prev,
      line_items: [...prev.line_items, {
        product_id: "",
        brand: "",
        model: "",
        variant_id: "",
        variant_name: "",
        variant_sku: "",
        item_short_name: "",
        item_description: "",
        line_note: "",
        quantity: 1,
        unit: "Adet",
        currency: "EUR",
        unit_price: 0,
        cost_price: 0,
        is_optional: false
      }]
    }));
  };

  const removeLineItem = (index) => {
    if (formData.line_items.length === 1) {
      toast.error("At least one line item required");
      return;
    }
    setFormData(prev => ({
      ...prev,
      line_items: prev.line_items.filter((_, i) => i !== index)
    }));
  };

  const calculateLineTotal = (item) => {
    const quantity = parseFloat(item.quantity) || 0;
    const unitPrice = parseFloat(item.unit_price) || 0;
    return quantity * unitPrice;
  };

  const calculateTotals = () => {
    if (!formData) return {};
    const totals = {};
    formData.line_items.forEach(item => {
      if (!item.is_optional) {
        const currency = item.currency || 'EUR';
        totals[currency] = (totals[currency] || 0) + calculateLineTotal(item);
      }
    });
    return totals;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validasyon: İndirim kontrolü
    if (formData.discount_type !== 'none' && formData.discount_value > 0) {
      const totals = calculateTotals();
      const totalAmount = Object.values(totals).reduce((sum, val) => sum + val, 0);
      
      let discountAmount = 0;
      if (formData.discount_type === 'percent') {
        discountAmount = totalAmount * (formData.discount_value / 100);
        
        // %10 üzeri indirimler için onay
        if (formData.discount_value > 10) {
          const confirmed = window.confirm(
            `⚠️ YÜKSEK İNDİRİM UYARISI ⚠️\n\n` +
            `%${formData.discount_value} indirim uygulamak istediğinizden emin misiniz?\n\n` +
            `Ara Toplam: ${totalAmount.toFixed(2)} ${formData.discount_currency || 'EUR'}\n` +
            `İndirim: -${discountAmount.toFixed(2)} ${formData.discount_currency || 'EUR'}\n` +
            `Toplam: ${(totalAmount - discountAmount).toFixed(2)} ${formData.discount_currency || 'EUR'}\n\n` +
            `Onaylıyor musunuz?`
          );
          if (!confirmed) {
            toast.info("İndirim değerini düzenleyin");
            return;
          }
        }
      } else {
        discountAmount = formData.discount_value;
      }
      
      // Negatif toplam kontrolü
      if (totalAmount - discountAmount < 0) {
        const errorMsg = `❌ HATA: İndirim Çok Yüksek!\n\n` +
          `Ara Toplam: ${totalAmount.toFixed(2)} ${formData.discount_currency || 'EUR'}\n` +
          `İndirim: -${discountAmount.toFixed(2)} ${formData.discount_currency || 'EUR'}\n` +
          `Toplam: ${(totalAmount - discountAmount).toFixed(2)} ${formData.discount_currency || 'EUR'}\n\n` +
          `İndirim tutarı, ara toplamdan fazla olamaz!\n` +
          `Lütfen indirim değerini düzeltin.`;
        
        alert(errorMsg);
        toast.error("İndirim tutarı hatalı!");
        return;
      }
    }
    
    setSaving(true);
    try {
      await axios.put(`${API}/quotations/${id}`, formData);
      toast.success("Quotation updated successfully");
      navigate(`/quotations/${type}`);
    } catch (error) {
      console.error("Error updating quotation:", error);
      toast.error(error.response?.data?.detail || "Failed to update quotation");
    } finally {
      setSaving(false);
    }
  };

  const handleRevise = async () => {
    if (!window.confirm("Create a new revision? This will duplicate the quotation.")) return;
    
    try {
      const response = await axios.post(`${API}/quotations/${id}/revise`);
      toast.success("Revision created");
      navigate(`/quotations/${type}/edit/${response.data.id}`);
    } catch (error) {
      console.error("Error creating revision:", error);
      toast.error("Failed to create revision");
    }
  };

  const handleStatusUpdate = async () => {
    try {
     await axios.patch(`${API}/quotations/${id}/status`, {
  offer_status: statusForm.offer_status,
  rejection_reason: statusForm.rejection_reason || null,
  invoice_number: statusForm.invoice_number || null
});

      toast.success("Status updated");
      setStatusDialogOpen(false);
      fetchQuotation();
    } catch (error) {
      console.error("Error updating status:", error);
      toast.error("Failed to update status");
    }
  };

  if (loading || !formData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    );
  }

  const totals = calculateTotals();

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b border-border/40 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate(`/quotations/${type}`)}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-heading font-bold">Edit Quotation</h1>
                <p className="text-xs text-muted-foreground">{formData.quote_no}</p>
              </div>
            </div>
            
            {/* Consistent Button Order: Revision Dropdown, Add Item, Cancel, Save, New Revision, Update Status, Preview */}
            <div className="flex gap-2">
              {revisions.length > 1 && (
                <select
                  className="px-3 py-2 border rounded bg-background"
                  value={id}
                  onChange={(e) => navigate(`/quotations/${type}/edit/${e.target.value}`)}
                >
                  {revisions.map(rev => (
                    <option key={rev.id} value={rev.id}>
                      {rev.quote_no}
                    </option>
                  ))}
                </select>
              )}
              <Button type="button" onClick={addLineItem} variant="outline">
                <Plus className="h-4 w-4 mr-2" />
                Add Item
              </Button>
              <Button type="button" variant="outline" onClick={() => navigate(`/quotations/${type}`)}>
                Cancel
              </Button>
              <Button type="submit" disabled={saving} onClick={handleSubmit}>
                <Save className="h-4 w-4 mr-2" />
                {saving ? "Saving..." : "Save"}
              </Button>
              <Button variant="outline" onClick={handleRevise}>
                <GitBranch className="h-4 w-4 mr-2" />
                New Revision
              </Button>
              <Dialog open={statusDialogOpen} onOpenChange={setStatusDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline">
                    Update Status
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Update Status</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 mt-4">
                    <div>
                      <Label>Offer Status</Label>
                      <select
                        className="w-full p-2 border rounded bg-background"
                        value={statusForm.offer_status}
                        onChange={(e) => setStatusForm({...statusForm, offer_status: e.target.value})}
                      >
                        <option value="pending">Pending</option>
                        <option value="accepted">Accepted</option>
                        <option value="rejected">Rejected</option>
                      </select>
                    </div>
                    {statusForm.offer_status === 'rejected' && (
                      <div>
                        <Label>Rejection Reason</Label>
                        <Textarea
                          value={statusForm.rejection_reason}
                          onChange={(e) => setStatusForm({...statusForm, rejection_reason: e.target.value})}
                          rows={3}
                        />
                      </div>
                    )}
                    {statusForm.offer_status === 'accepted' && (
                      <div>
                        <Label>Invoice Number (optional)</Label>
                        <Input
                          value={statusForm.invoice_number}
                          onChange={(e) => setStatusForm({...statusForm, invoice_number: e.target.value})}
                        />
                      </div>
                    )}
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={() => setStatusDialogOpen(false)}>Cancel</Button>
                      <Button onClick={handleStatusUpdate}>Update</Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
              <Button onClick={() => navigate(`/quotations/${type}/preview/${id}`)}>
                <FileText className="h-4 w-4 mr-2" />
                Preview
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8 max-w-6xl">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Same structure as CreateQuotation but with edit functionality */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Basic Information</h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Customer *</Label>
                <select
                  name="customer_id"
                  value={formData.customer_id}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded bg-background"
                  required
                >
                  {customers.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <Label>DEMART Yetkilisi *</Label>
                <select
                  name="representative_id"
                  value={formData.representative_id || ""}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded bg-background"
                  required
                >
                  <option value="">DEMART yetkilisi seçin</option>
                  {representatives.map(r => (
                    <option key={r.id} value={r.id}>{r.name} - {r.phone}</option>
                  ))}
                </select>
              </div>
              <div>
                <Label>Language / Dil *</Label>
                <select
                  name="language"
                  value={formData.language}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded bg-background font-semibold"
                >
                  <option value="turkish">🇹🇷 Türkçe</option>
                  <option value="english">🇬🇧 English</option>
                </select>
              </div>
              <div className="col-span-2">
                <Label>Subject *</Label>
                <Input
                  name="subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div>
                <Label>Project Code</Label>
                <Input
                  name="project_code"
                  value={formData.project_code || ""}
                  onChange={handleInputChange}
                />
              </div>
              <div>
                <Label>Validity (days)</Label>
                <Input
                  type="number"
                  name="validity_days"
                  value={formData.validity_days}
                  onChange={handleInputChange}
                />
              </div>
            </div>
          </Card>

          {/* Line Items - same as CreateQuotation */}
          <Card className="p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Line Items</h2>
              <Button type="button" onClick={addLineItem} size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Item
              </Button>
            </div>
            
            <div className="space-y-4">
              {formData.line_items.map((item, index) => (
                <div key={index} className="p-4 bg-background/50 border rounded space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-mono">Item {index + 1}</span>
                    {formData.line_items.length > 1 && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeLineItem(index)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-12 gap-3">
                    <div className="col-span-3">
                      <Label>Product</Label>
                      <select
                        value={item.product_id || ""}
                        onChange={(e) => handleProductSelect(index, e.target.value)}
                        className="w-full p-2 border rounded bg-background text-sm"
                      >
                        <option value="">Manual entry</option>
                        {products.map(p => (
                          <option key={p.id} value={p.id}>
                            {p.brand ? `${p.brand} - ` : ''}{p.item_short_name}
                          </option>
                        ))}
                      </select>
                    </div>
                    {/* Model/Variant Dropdown */}
                    <div className="col-span-3">
                      <Label>Model / Variant {getProductModels(item.product_id).length > 0 && <span className="text-red-500">*</span>}</Label>
                      <select
                        value={item.variant_id || ""}
                        onChange={(e) => handleVariantSelect(index, e.target.value)}
                        className={`w-full p-2 border rounded bg-background text-sm ${
                          getProductModels(item.product_id).length > 0 && !item.variant_id 
                            ? 'border-orange-400 bg-orange-50' 
                            : ''
                        }`}
                        disabled={!item.product_id || getProductModels(item.product_id).length === 0}
                      >
                        <option value="">
                          {!item.product_id 
                            ? "Select product first" 
                            : getProductModels(item.product_id).length === 0 
                              ? "No models" 
                              : "Select model..."}
                        </option>
                        {getProductModels(item.product_id).map((m, mIdx) => (
                          <option key={m.id || mIdx} value={m.id || m.model_name}>
                            {m.model_name} {m.sku ? `(${m.sku})` : ''} {m.price ? `- ${m.price}` : ''}
                          </option>
                        ))}
                      </select>
                      {item.variant_sku && (
                        <p className="text-xs text-muted-foreground mt-1">SKU: {item.variant_sku}</p>
                      )}
                      {/* Legacy uyarısı */}
                      {item.product_id && getProductModels(item.product_id).length > 0 && !item.variant_id && (
                        <p className="text-xs text-orange-500 mt-1">⚠️ Model seçilmemiş / Legacy</p>
                      )}
                    </div>
                    <div className="col-span-6">
                      <Label>Item Name</Label>
                      <Input
                        value={item.item_short_name}
                        onChange={(e) => handleLineItemChange(index, 'item_short_name', e.target.value)}
                      />
                    </div>
                    <div className="col-span-2">
                      <Label>Quantity</Label>
                      <Input
                        type="number"
                        value={item.quantity}
                        onChange={(e) => handleLineItemChange(index, 'quantity', parseFloat(e.target.value))}
                      />
                    </div>
                    <div className="col-span-2">
                      <Label>Unit</Label>
                      <Input
                        value={item.unit}
                        onChange={(e) => handleLineItemChange(index, 'unit', e.target.value)}
                      />
                    </div>
                    <div className="col-span-2">
                      <Label>Currency</Label>
                      <select
                        value={item.currency}
                        onChange={(e) => handleLineItemChange(index, 'currency', e.target.value)}
                        className="w-full p-2 border rounded bg-background"
                      >
                        <option value="EUR">EUR</option>
                        <option value="USD">USD</option>
                        <option value="TRY">TRY</option>
                      </select>
                    </div>
                    <div className="col-span-2">
                      <Label>Unit Price</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={item.unit_price}
                        onChange={(e) => handleLineItemChange(index, 'unit_price', parseFloat(e.target.value))}
                      />
                    </div>
                    <div className="col-span-12">
                      <Label>Description</Label>
                      <Textarea
                        value={item.item_description || ""}
                        onChange={(e) => handleLineItemChange(index, 'item_description', e.target.value)}
                        rows={2}
                      />
                    </div>
                    <div className="col-span-12 flex items-center gap-4">
                      <label className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={item.is_optional}
                          onChange={(e) => handleLineItemChange(index, 'is_optional', e.target.checked)}
                        />
                        <span className="text-sm">Optional Item</span>
                      </label>
                      <div className="ml-auto text-lg font-bold text-accent">
                        Total: {calculateLineTotal(item).toFixed(2)} {item.currency}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-6 pt-4 border-t">
              <div className="text-right space-y-2">
                {Object.keys(totals).map(currency => (
                  <div key={currency} className="text-xl font-bold text-accent">
                    Total: {totals[currency].toFixed(2)} {currency}
                  </div>
                ))}
              </div>
            </div>
          </Card>

          {/* General Discount */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Genel İndirim (Toplam Üzerinden)</h2>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label>İndirim Tipi</Label>
                <select
                  name="discount_type"
                  value={formData.discount_type || "none"}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded bg-background"
                >
                  <option value="none">İndirim Yok</option>
                  <option value="percent">Yüzde (%)</option>
                  <option value="fixed">Sabit Tutar</option>
                </select>
              </div>
              <div>
                <Label>İndirim Değeri</Label>
                <Input
                  type="number"
                  step="0.01"
                  name="discount_value"
                  value={formData.discount_value || 0}
                  onChange={handleInputChange}
                  disabled={!formData.discount_type || formData.discount_type === 'none'}
                />
              </div>
              <div>
                <Label>Para Birimi</Label>
                <select
                  name="discount_currency"
                  value={formData.discount_currency || "EUR"}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded bg-background"
                  disabled={!formData.discount_type || formData.discount_type === 'none'}
                >
                  <option value="EUR">EUR</option>
                  <option value="USD">USD</option>
                  <option value="TRY">TRY</option>
                </select>
              </div>
            </div>
          </Card>

          {/* International & Shipping */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">International & Shipping</h2>
            <div className="space-y-4">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  name="is_international"
                  checked={formData.is_international}
                  onChange={handleInputChange}
                />
                <span>International Order</span>
              </label>
              
              {formData.is_international && (
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Import/Freight/Customs Cost</Label>
                    <Input
                      type="number"
                      step="0.01"
                      name="import_extra_cost_amount"
                      value={formData.import_extra_cost_amount || 0}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div>
                    <Label>Currency</Label>
                    <select
                      name="import_extra_cost_currency"
                      value={formData.import_extra_cost_currency || "EUR"}
                      onChange={handleInputChange}
                      className="w-full p-2 border rounded bg-background"
                    >
                      <option value="EUR">EUR</option>
                      <option value="USD">USD</option>
                      <option value="TRY">TRY</option>
                    </select>
                  </div>
                </div>
              )}
              
              <div>
                <Label>Shipping Terms (Incoterms)</Label>
                <select
                  name="shipping_term"
                  value={formData.shipping_term || ""}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded bg-background"
                >
                  <option value="">Select...</option>
                  {INCOTERMS.map(term => (
                    <option key={term} value={term}>{term}</option>
                  ))}
                </select>
              </div>
            </div>
          </Card>

          {/* Terms & Notes */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Terms & Notes</h2>
            <div className="space-y-4">
              <div>
                <Label>Delivery Time</Label>
                <Input name="delivery_time" value={formData.delivery_time || ""} onChange={handleInputChange} />
              </div>
              <div>
                <Label>Delivery Terms</Label>
                <Textarea name="delivery_terms" value={formData.delivery_terms || ""} onChange={handleInputChange} rows={2} />
              </div>
              <div>
                <Label>Payment Terms</Label>
                <Textarea name="payment_terms" value={formData.payment_terms || ""} onChange={handleInputChange} rows={2} />
              </div>
              <div>
                <Label>Notes</Label>
                <Textarea name="notes" value={formData.notes || ""} onChange={handleInputChange} rows={3} />
              </div>
            </div>
          </Card>

          {/* Actions */}
          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={() => navigate(`/quotations/${type}`)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving} className="bg-primary">
              <Save className="h-4 w-4 mr-2" />
              {saving ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditQuotation;
